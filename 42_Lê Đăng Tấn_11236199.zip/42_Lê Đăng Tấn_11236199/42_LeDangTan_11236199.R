# bai1
data1 <- read.table("data1.txt", header = TRUE)

bai1 <- data[(data1$khoi == 'A1' | data1$khoi == 'D1') & data1$M1 > 7.5, ]

ans_1 <- bai1[sample(nrow(bai1), 5), ]

print(ans_1)

# bai2
data32 <- read.table("data32.txt", header = TRUE)

demsonhanvien <- table(data32$Group) 

print(demsonhanvien)

boxplot(Data ~ Group, data = data32, 
        main = "Đồ thị Boxplot cho thu nhập",
        xlab = "Nhóm",
        ylab = "Thu nhập",
        col = c("lightblue", "lightgreen"))


# bai3
data2 <- read.table("data2.txt", header = TRUE)

colors <- ifelse(data2$Gioitinh == "Nam", "lightblue", "lightgreen")
pch <- ifelse(data2$Gioitinh == "Nam", 19, 17)

pairs(data2[c("Thunhap", "Chitieu")], col = colors, pch = pch, 
      main = "Mối quan hệ giữa Thu nhập và Chi tiêu theo Giới tính")




